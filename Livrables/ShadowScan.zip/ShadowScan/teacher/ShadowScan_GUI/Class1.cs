﻿using System.Collections.Generic;

public class JsonManager
{
    public List<string> Ressources { get; set; }
    // public List<string> type_2 { get; set; }
    // public List<string> type_3 { get; set; }
}